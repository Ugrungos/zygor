local ZGV = ZygorGuidesViewer
if not ZGV then return end

local GuideMenu = ZGV.GuideMenu

GuideMenu.HomeVersion = 1
GuideMenu.Home={
	{"banner", image=ZGV.DIR.."\\Skins\\banner"},

	{"title", text=[[|cffffcc00World of Warcraft Classic Release | October 15th, 2019 1.0.21145|r.]]},
	



}


-- faction="Alliance" {"separator"},