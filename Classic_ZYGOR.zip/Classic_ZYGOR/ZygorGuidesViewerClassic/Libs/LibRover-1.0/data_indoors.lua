local name,addon = ...

addon.LibRoverData = addon.LibRoverData or {}
local data=addon.LibRoverData

-- INDOOR ZONES. Used when there's no map number change.
data.basenodes.indoorzones = {
}

