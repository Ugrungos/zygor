local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end
if ZGV:DoMutex("DailiesCLEGION") then return end
ZygorGuidesViewer.GuideMenuTier = "TRI"
