local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end
if not ZygorGuidesViewer.ItemScore then return end
ZygorGuidesViewer.ItemScore.Items = ZygorGuidesViewer.ItemScore.Items or {}
